(this["webpackJsonp@pancakeswap/interface"]=this["webpackJsonp@pancakeswap/interface"]||[]).push([[5],{1063:function(a,p){}}]);
//# sourceMappingURL=5.3ea1ac43.chunk.js.map